package bao;

import javax.validation.Valid;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller  
public class EmployeeController {
	@RequestMapping("/hello")  
    public String display(Model m)  
    {  
        m.addAttribute("emp", new Employee());  
        return "viewpage";  
    }  
    @RequestMapping("/helloagain")  
    public ModelAndView submitForm( @Valid @ModelAttribute("emp") Employee e, BindingResult br,ModelMap m)  
    {  
        if(br.hasErrors())  
        {  
            return new ModelAndView("viewpage");  
        }  
        else  
        { 
        	Configuration cfg = new Configuration();
    		cfg.configure("hibernate.cfg.xml"); 

    		SessionFactory factory = cfg.buildSessionFactory();
    		Session session = factory.openSession();
    		Transaction tx = session.beginTransaction();
    		Employee obj = new Employee();
    		obj.setName(e.getName());
    		obj.setPass(e.getPass());
    		session.save(obj);
    		tx.commit();
    		session.close();
    		m.addAttribute("msg","registration successfully");
    		
    		return new ModelAndView("viewpage","command",new Employee() ) ;  
        }  }  
}
